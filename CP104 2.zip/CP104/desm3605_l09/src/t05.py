"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-11-14"
------------------------------------------------------------------------
"""

# Imports
from functions import password_strength
# Constants

password = str(input("Password: "))

password_strength(password)