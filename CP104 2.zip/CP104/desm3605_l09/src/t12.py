"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-11-14"
------------------------------------------------------------------------
"""

# Imports
from functions import comma_period_replace
# Constants

string = str(input("String: "))

out = comma_period_replace(string)

print(out)