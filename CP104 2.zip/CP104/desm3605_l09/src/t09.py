"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-11-14"
------------------------------------------------------------------------
"""

# Imports
from functions import count_special_chars
# Constants

string = str(input("String: "))

special_ = count_special_chars(string)

print(special_)