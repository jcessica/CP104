"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-11-14"
------------------------------------------------------------------------
"""

# Imports
from functions import vowel_count
# Constants

word = str(input("Word: "))

vowels_ = vowel_count(word)

print(vowels_)