"""
------------------------------------------------------------------------
Assignment 1, Task 2
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-09-25"
------------------------------------------------------------------------
"""

age = int(input("What is your age? "))

band = input("What is your favourite band? ")

print("I am",age,"years old and",band,"is my favourite band.")