"""
------------------------------------------------------------------------
Assignment 1, Task 4
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-09-25"
------------------------------------------------------------------------
"""

cost_dosa = float(input("Cost of 1 dosa: $"))

number_dosa = int(input("Number of dosa: "))

total_cost = cost_dosa*number_dosa

print("Total cost of",number_dosa,"dosa: $ ",total_cost)