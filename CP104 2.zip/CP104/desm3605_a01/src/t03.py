"""
------------------------------------------------------------------------
Assignment 1, Task 3
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-09-25"
------------------------------------------------------------------------
"""
#Miles to Kilometer conversion ratio
MILES_KM = 1.61

miles = float(input("Length in miles: "))

kilometers = miles*MILES_KM

print("Length in km: ",kilometers)