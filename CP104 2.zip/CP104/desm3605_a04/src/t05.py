"""
------------------------------------------------------------------------
Assignment 4, Task 5
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-10-27"
------------------------------------------------------------------------
"""

# Imports
from functions import hoo_rah

# Constants

number = int(input("Enter number: "))

division = hoo_rah(number)

print(division)