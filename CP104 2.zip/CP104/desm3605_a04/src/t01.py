"""
------------------------------------------------------------------------
Assignment 4, Task 1
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-10-27"
------------------------------------------------------------------------
"""

# Imports
from functions import day_name

# Constants

day_num = int(input("Enter day number: "))

day = day_name(day_num)

print(day)
