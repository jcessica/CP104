"""
------------------------------------------------------------------------
Lab 6, Task 8
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-10-23"
------------------------------------------------------------------------
"""

# Imports
from functions import draw_hollow_triangle
# Constants

width = int(input("Width: "))

char = str(input("Character: "))

print()

draw_hollow_triangle(width, char)