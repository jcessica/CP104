"""
------------------------------------------------------------------------
Lab 6, Task 11
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-10-23"
------------------------------------------------------------------------
"""

# Imports
from functions import retirement
# Constants

age = int(input("Age: " ))

salary = float(input("Salary: "))

increase = float(input("Pay increase: "))

retirement(age, salary, increase)
