"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-11-10"
------------------------------------------------------------------------
"""

# Imports
from functions import interest_table
# Constants

principal_amount = 100
interest_rate = 10
payment = 50


interest_table(principal_amount, interest_rate, payment)