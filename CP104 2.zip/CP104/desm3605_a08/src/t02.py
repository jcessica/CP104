"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-11-24"
------------------------------------------------------------------------
"""
# Imports
from functions import pluralize
# Constants

string_ = str(input('String:'))

print(pluralize(string_))

