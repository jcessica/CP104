"""
------------------------------------------------------------------------
Lab 5, Task 15
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-10-12"
------------------------------------------------------------------------
"""

# Imports
from functions import fast_food
# Constants

price = fast_food()

print(f"{price:.2f}")



