"""
------------------------------------------------------------------------
Lab 11, Task 2
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-11-29"
------------------------------------------------------------------------
"""

# Imports
from functions import generate_matrix_char
# Constants

print(generate_matrix_char(3, 4))