"""
------------------------------------------------------------------------
Lab 11, Task 10
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-11-29"
------------------------------------------------------------------------
"""

# Imports
from functions import find_word_horizontal
# Constants


print(find_word_horizontal([['a'], ['a'], ['a']], 'a'))
