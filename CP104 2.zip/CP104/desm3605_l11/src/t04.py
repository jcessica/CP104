"""
------------------------------------------------------------------------
Lab 11, Task 4
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-11-29"
------------------------------------------------------------------------
"""

# Imports
from functions import generate_matrix_char,print_matrix_char
# Constants

matrix = generate_matrix_char(3, 4)

print_matrix_char(matrix)