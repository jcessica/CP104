"""
------------------------------------------------------------------------
Lab 11, Task 5
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-11-29"
------------------------------------------------------------------------
"""

# Imports
from functions import words_to_matrix
# Constants

matrix = words_to_matrix(["cat", "dog", "big"])

print(matrix)
