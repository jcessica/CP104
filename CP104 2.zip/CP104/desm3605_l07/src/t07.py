"""
------------------------------------------------------------------------
Lab 1, Task 7
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-11-01"
------------------------------------------------------------------------
"""

# Imports
from functions import meal_costs

# Constants
meal = meal_costs()

print(meal)
