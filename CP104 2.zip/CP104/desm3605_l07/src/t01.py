"""
------------------------------------------------------------------------
Lab 1, Task 1
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-11-01"
------------------------------------------------------------------------
"""

# Imports
from functions import hi_lo_game
# Constants

high = int(input("Enter a number: "))

hi_lo_game(high)
