"""
------------------------------------------------------------------------
Lab 1, Task 9
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-11-01"
------------------------------------------------------------------------
"""

# Imports
from functions import get_int
# Constants

low = int(input("Enter low number: "))

high = int(input("Enter high number: "))

int_ = get_int(low, high)

print(int_)