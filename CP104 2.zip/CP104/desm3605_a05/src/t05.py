"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-11-02"
------------------------------------------------------------------------
"""

# Imports
from functions import multiplication_table
# Constants

multiplication_table(2, 4)
print()
multiplication_table(5, 7)
print()
multiplication_table(1, 3)
