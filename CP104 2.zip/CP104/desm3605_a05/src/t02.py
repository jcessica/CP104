"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-11-02"
------------------------------------------------------------------------
"""

# Imports
from functions import calories_treadmill
# Constants



per_min = float(input("Calories burned/min: "))

minutes = int(input("Minutes on treadmill: "))

calories_treadmill(per_min,minutes)



