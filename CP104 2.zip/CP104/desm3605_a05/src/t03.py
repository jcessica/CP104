"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-11-02"
------------------------------------------------------------------------
"""

# Imports
from functions import arrow_up
# Constants

rows = int(input("Enter rows: "))

arrow_up(rows)


