"""
------------------------------------------------------------------------
Assignment 7, Task 2
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-11-16"
------------------------------------------------------------------------
"""

# Imports
from functions import list_positives
# Constants

print(list_positives())