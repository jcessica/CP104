"""
------------------------------------------------------------------------
Assignment 7, Task 5
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-11-16"
------------------------------------------------------------------------
"""

# Imports
from functions import verify_sorted,list_positives
# Constants

numbers = list_positives()

sorting = verify_sorted(numbers)


print(sorting)