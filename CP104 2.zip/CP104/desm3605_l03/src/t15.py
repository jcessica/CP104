"""
------------------------------------------------------------------------
Lab 3, Task 15
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-09-25"
------------------------------------------------------------------------
"""

integer = 654321
decimal = 654.32
phrase = "Hello World"

#Integer formats
print(f"{integer:d}")
print(f"{integer:f}")
#print(f"{integer:s}")

#Decimal formats
#print(f"{decimal:d}")
print(f"{decimal:f}")
#print(f"{decimal:s}")

#Phrase formats
#print(f"{phrase:f}")
#print(f"{phrase:d}")
print(f"{phrase:s}")