"""
------------------------------------------------------------------------
Lab 3, Task 3
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-09-25"
------------------------------------------------------------------------
"""

print('Selected quotes from Mark Twain:')
print()
print()
print('"Do the right thing. It will gratify some people and astonish the rest."')
print('"All generalizations are false, including this one."')
print('"It is better to keep your mouth closed and let people think you are a fool')
print('than to open it and remove all doubt."')