"""
------------------------------------------------------------------------
Lab 3, Task 6
------------------------------------------------------------------------
Author: Jessica Desmond
ID:     169033605
Email:  desm3605@mylaurier.ca
__updated__ = "2023-09-25"
------------------------------------------------------------------------
"""

cost = float(input("Enter cost: $"))

quantity = int(input("Enter quantity: "))

total = cost*quantity

print()
print()
print(f"Given a cost of ${cost:.2f} and a quantity of {quantity} the total is ${total:.2f}")


